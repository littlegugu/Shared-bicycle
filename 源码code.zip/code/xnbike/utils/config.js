module.exports = {
  appid: 'wx5b603fddb2c1bca9',
  secret: '28c8cc13984a6d163f904db5cd063296',
  mapKey: 'EBMBZ-N5FWU-JYOVP-B3LKB-63JCQ-XBFHT',
  webServer: "http://192.168.4.22:8888",
  logServer: "http://192.168.4.250"
};