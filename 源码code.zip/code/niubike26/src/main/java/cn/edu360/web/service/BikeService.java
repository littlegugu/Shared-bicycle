package cn.edu360.web.service;

import cn.edu360.web.entity.Bike;

public interface BikeService {

    void save(Bike bike);
}
